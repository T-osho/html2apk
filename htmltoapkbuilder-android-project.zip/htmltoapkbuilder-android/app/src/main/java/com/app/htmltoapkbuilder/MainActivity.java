package com.app.htmltoapkbuilder;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.*;
import androidx.webkit.WebViewAssetLoader;
public class MainActivity extends Activity {
  WebView w;
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    final WebViewAssetLoader L = new WebViewAssetLoader.Builder()
      .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
    w = new WebView(this);
    setContentView(w);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    w.setWebChromeClient(new WebChromeClient());
    w.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        return L.shouldInterceptRequest(r.getUrl());
      }
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        if ("appassets.androidplatform.net".equals(r.getUrl().getHost())) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) {}
        return true;
      }
    });
    w.loadUrl("https://appassets.androidplatform.net/www/index.html");
  }
  @Override public void onBackPressed() {
    if (w.canGoBack()) w.goBack(); else super.onBackPressed();
  }
}
