Upload this folder to GitHub (keep .github). Actions > Build APK produces the installable APK.
Or open in Android Studio and run Build > Build APK.
